# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 15:50:47 2022

@author: omoura
"""

from PyPDF2 import PdfMerger
import glob
import sys



def mergePDF(path, file_ext, filename):
    merger = PdfMerger()
    l = len(filename)
    
    print('Efetuando o join ...')
    
    for pdf in glob.glob(path + '/' + file_ext):
        if pdf[-l:] != filename: # Não realizar o join do mesmo arquivo chamado <filename>
            merger.append(pdf)
    
    return merger



if __name__ == '__main__':
    
    #path = r'C:\Users\OMOURA\Desktop\teste'
    pathO = sys.argv[1]
    pathD = sys.argv[2]
    filename = 'pdfJoined.pdf'
    
    file_ext = '*.pdf'
    
    print('Origem: ' + pathO)
    print('Destino: ' + pathD)
    print()
    
    merger = mergePDF(pathO, file_ext, filename)
    print()
    
    print('Exportando ...\n')
    merger.write(pathD + '\\' + filename)
    merger.close()