# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 15:50:47 2022

@author: omoura
"""

from PyPDF2 import PdfMerger
import glob
import sys



def mergePDF(path, file_ext):
    merger = PdfMerger()
    
    for pdf in glob.glob(path + '/' + file_ext):
        merger.append(pdf)
    
    return merger



if __name__ == '__main__':
    
    #path = r'C:\Users\OMOURA\Desktop\teste'
    pathO = sys.argv[1]
    pathD = sys.argv[2]
    
    file_ext = '*.pdf'
    
    
    merger = mergePDF(pathO, file_ext)
    
    merger.write(pathD+'/result.pdf')
    merger.close()